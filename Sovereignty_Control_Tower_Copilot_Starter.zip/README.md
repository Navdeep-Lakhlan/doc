# Sovereignty Control Tower — GitHub Copilot Starter

This is the Copilot-specific starter pack.

## Setup
1. Extract this ZIP into the root of your company-approved repository.
2. Open that repository in VS Code.
3. Confirm GitHub Copilot is enabled under your organisation's policies.
4. Open `.github/copilot-instructions.md` and `docs/PROJECT_CONTEXT.md`.
5. Start a Copilot Chat session in Agent mode (use Plan mode first if available).
6. Paste the task from `docs/prompts/00-phase-zero-discovery.md`.
7. Review the proposed discovery plan before allowing code changes.

## Included
- `.github/copilot-instructions.md`: repository-wide Copilot guidance.
- `docs/PROJECT_CONTEXT.md`: product and architecture context.
- `docs/prompts/`: seven phased implementation prompts.

Use only company-approved Copilot features and data classifications. Do not provide internal materials to unapproved AI services.
