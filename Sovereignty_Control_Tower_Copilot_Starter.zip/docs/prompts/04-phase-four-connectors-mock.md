# Phase 4 — Connector Framework and Mock Integrations

Read `docs/PROJECT_CONTEXT.md` and the approved connector contract.

## Objective
Create a secure backend connector framework with deterministic mock adapters.

## Requirements
- Define a common connector contract: identity, capability discovery, health, collection request, normalised result, timestamps and sanitised error model.
- Implement mock adapters for Dell iDRAC Redfish, NVIDIA DCGM/Prometheus, Nutanix Prism Central and OpenShift/Kubernetes.
- Mock data must be synthetic and must not resemble real internal hostnames, IPs, credentials or customer data.
- Keep connector execution in the backend. Frontend calls application APIs only.
- Add bounded timeouts, safe retry policy, structured logs without secrets and connector-level permissions.
- Make connector availability and evidence collection status visible without treating them as control assessments.
- Document the exact information required from platform owners before real integration.

## Acceptance criteria
- Each mock adapter can be exercised without live infrastructure.
- Connector failures are represented safely and consistently.
- Tests cover timeouts, malformed responses, unsupported capabilities and partial collection.
- No real endpoint paths or API versions are guessed.
