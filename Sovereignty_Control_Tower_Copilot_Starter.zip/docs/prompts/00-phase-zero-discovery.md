# Phase 0 — Repository and Architecture Discovery

You are assisting with the Sovereignty Control Tower project. First read `AGENTS.md` and `docs/PROJECT_CONTEXT.md`.

## Objective
Understand the current machine, repository and constraints before writing application code.

## Instructions
1. Inspect the repository tree, existing README files, manifests, lockfiles, configuration, tests and CI workflows.
2. Identify whether this is an empty repository or an existing application.
3. Report detected OS, runtime/tool versions and existing stack only where you can verify them.
4. Identify existing conventions, linting, formatting, test commands and build commands.
5. Compare the current repository with the proposed React/TypeScript + FastAPI + PostgreSQL baseline. Do not force a migration if the repository already has an approved standard.
6. Identify company-specific constraints that need confirmation; do not guess.
7. Propose a minimal target folder structure and local development workflow.
8. List dependencies that would be needed, explaining why. Do not install anything yet.
9. Identify security, privacy, deployment and integration risks.
10. Produce a phased implementation plan with small milestones and testable acceptance criteria.

## Output
Create or propose `docs/ARCHITECTURE_DECISIONS.md` containing:
- Repository findings
- Proposed architecture and rationale
- Folder structure
- Local run/test workflow
- Dependency proposal
- Security considerations
- Open questions and owners to consult
- Phase 1 implementation plan

## Constraints
Do not modify application code, install packages, create infrastructure, connect to endpoints or add secrets in this phase. Present the findings and wait for approval.
