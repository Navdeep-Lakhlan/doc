# Phase 6 — Live Integration and Security Hardening

Do not begin until the platform team has supplied approved endpoint specifications, access approvals and test environment details.

## Objective
Replace selected mock adapters with real, read-only integrations safely.

## Pre-flight checklist
- Approved endpoint URL/DNS, port, API path and API version
- Confirmed product/firmware/software versions and supported capabilities
- Network route/firewall approval
- Dedicated least-privilege service identity and credential delivery through approved secrets management
- TLS certificate chain and trust configuration
- Data classification, retention and evidence handling approval
- Test environment and rollback/disable procedure
- Monitoring, rate limits and operational owner

## Requirements
- Implement one connector at a time behind the existing adapter interface.
- Verify API capabilities against vendor documentation and the actual target version.
- Use read-only access wherever possible.
- Never disable TLS verification or hard-code secrets.
- Apply bounded timeouts, rate limits, safe retries, input validation and sanitised errors.
- Log audit-relevant events without credentials or sensitive payloads.
- Add contract tests, integration tests in approved test environments and failure-mode tests.
- Keep mock mode available for local development and automated tests.

## Acceptance criteria
- Each live integration has documented version/capability support and owner approval.
- No secrets appear in source, logs, test fixtures or error messages.
- Connector can be disabled independently.
- Evidence provenance and collection timestamps are retained.
- No control is automatically passed based solely on a successful connector response.
