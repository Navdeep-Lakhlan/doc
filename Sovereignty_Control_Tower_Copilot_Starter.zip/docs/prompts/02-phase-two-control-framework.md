# Phase 2 — Control Framework and Dimension Pages

Read the project context and approved control-framework source before implementation.

## Objective
Create the data model and UI structure for the control catalogue and the eight sovereignty dimensions.

## Instructions
1. Ask for and locate the authoritative control workbook/framework. If it is not available, build only a clearly labelled synthetic example schema; do not fabricate real controls.
2. Define typed domain models for dimensions, controls, control versions, ownership, applicability and assessment criteria.
3. Keep dimension pages separate, with consistent layout and dimension-specific content slots.
4. Implement catalogue browsing, search and filters only against available source data.
5. Show source/provenance and version information for imported control definitions.
6. Make missing mappings explicit rather than filling them with guesses.
7. Add validation and tests for imports, duplicate identifiers, required fields and unknown dimension references.

## Acceptance criteria
- Eight independent dimension pages render.
- Catalogue is data-driven rather than hard-coded into page components.
- Imported control records preserve source identifiers and provenance.
- No unverified control count, ID, weight or regulatory mapping is presented as authoritative.
- Empty/unavailable framework states are clear and useful.
