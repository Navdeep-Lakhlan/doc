# Phase 3 — Evidence, Assessment, Exceptions and Approvals

Read the approved control model and project context.

## Objective
Implement the core assurance workflow with explicit separation between evidence collection and control assessment.

## Requirements
- Evidence records include source, collection time, validity/freshness, owner, storage reference, metadata, status and audit history as appropriate.
- Evidence states: Pending, Collected, Failed, Missing, Expired.
- Assessment states: Pass, Partial, Fail, Exception, Unknown.
- Never auto-mark a control Pass merely because evidence was collected.
- Support reviewer rationale, assessment criteria, evidence-to-control links and assessment history.
- Implement exception/remediation records with owner, due date, rationale, status and approval history.
- Implement approval workflow with role checks and auditable decisions.
- Use mock storage initially behind an abstraction; do not store sensitive evidence in the repository.
- Add access-control checks on backend operations.

## Acceptance criteria
- Evidence lifecycle and assessment lifecycle are independent in code and UI.
- Assessment changes require explicit criteria and authorised action.
- Exceptions and approvals are auditable.
- Tests cover invalid transitions, missing evidence, expired evidence and permission failures.
- Demo data is clearly labelled synthetic.
