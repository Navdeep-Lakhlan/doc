# Phase 1 — Application Foundation

Read `AGENTS.md`, `docs/PROJECT_CONTEXT.md` and the approved discovery/architecture decisions first.

## Objective
Create a minimal, runnable application foundation—not the whole product.

## Scope
- Establish the approved frontend and backend project structure.
- Implement the application shell: unified full-width header, independently scrollable sidebar and white/neutral workspace.
- Add route placeholders for the major modules and eight independent sovereignty dimension pages.
- Establish design tokens for charcoal, white, neutral grey and EY gold/yellow. Reserve green/amber/red for status.
- Add a small typed mock environment/region context and Refresh/Export UI affordances. Do not imply a real backend refresh or export exists unless implemented.
- Add backend health endpoint and basic configuration handling if FastAPI is approved.
- Add a simple frontend-to-backend health check if appropriate.
- Add linting, formatting, type checking and starter tests using repository-approved tools.
- Add a README with exact local setup and run instructions.

## Non-goals
No real infrastructure integrations, authentication implementation, real control catalogue, production database schema, evidence workflow or compliance scoring in this phase.

## Acceptance criteria
- Frontend and backend start locally using documented commands.
- Main layout works at desktop and reasonable smaller viewport widths.
- All eight dimension routes load independently.
- Navigation clearly identifies the active page.
- No invented control IDs or compliance claims.
- Automated smoke tests cover core routing and backend health.
- No secrets or internal endpoint details are committed.

Implement in small steps. Before editing, provide a short plan and list expected files. After implementation, run tests and report exact results.
