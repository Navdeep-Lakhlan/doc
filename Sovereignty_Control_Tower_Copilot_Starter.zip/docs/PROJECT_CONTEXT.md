# Sovereignty Control Tower — Project Context

## 1. Product purpose
Sovereignty Control Tower is an application-layer governance, assurance, evidence and observability platform for sovereign infrastructure and AI environments. It brings together control definitions, evidence, assessments, exceptions, approvals, infrastructure signals and assurance reporting.

It is not itself a certification authority. A telemetry signal or successful evidence collection does not automatically prove that a control passes.

## 2. Product and UI decisions
- Exact product name: **Sovereignty Control Tower**. Remove former product names from the application.
- Visual direction: restrained enterprise palette using charcoal, white, neutral grey and EY gold/yellow. Green, amber and red are reserved for status indicators.
- One unified full-width top header spanning the viewport. Include the EY mark (only if approved for use), product name, current page name, environment/region selectors and Refresh/Export controls.
- Sidebar starts below the header and scrolls independently.
- Each sovereignty dimension is a separate page.

## 3. Eight sovereignty dimensions
1. Governance
2. Data
3. Intelligence
4. Compute
5. Operations
6. Network
7. Supply Chain
8. Continuity

Do not invent the organisation's control catalogue. Earlier discussion mentioned 44 controls, but this count is unconfirmed. Validate control IDs, names, weights and mappings against an authoritative team-provided workbook or framework.

## 4. Functional modules
- Executive Overview
- Sovereignty Dimensions (eight separate pages)
- Control Catalogue
- Evidence Repository
- Exceptions & Remediation
- Models & AI Governance
- Infrastructure & GPU
- Network & Egress
- RAG Provenance
- Evidence Collectors
- Assurance Reports
- Approvals
- Administration

## 5. Proposed technology baseline
Treat these as proposed choices, not permission to install blindly. Inspect the repository, company-approved versions and hosting constraints first.
- Frontend: React + TypeScript
- Backend: Python + FastAPI
- Database: PostgreSQL, SQLAlchemy and Alembic
- Evidence storage: approved S3-compatible/internal object-store abstraction
- Identity: enterprise IdP / Keycloak via OIDC
- Secrets: Vault or approved secrets manager
- Background jobs: select an approved runner after deployment review
- Monitoring: Prometheus; NVIDIA DCGM Exporter metrics queried through Prometheus
- Deployment: OCI containers; Helm/GitOps if the target platform is confirmed

## 6. Core evidence and assessment model
Keep these lifecycles separate.

Evidence collection state:
- Pending
- Collected
- Failed
- Missing
- Expired

Control assessment state:
- Pass
- Partial
- Fail
- Exception
- Unknown

A collector may successfully retrieve evidence while the control assessment remains Partial, Fail or Unknown. Assessment requires defined criteria, scope, freshness and authorised review.

## 7. Connector approach
Build a connector interface and mock implementations first. Real integration work begins only after the platform team supplies approved endpoint specifications, versions, access methods and security requirements.

Potential adapters:
- Dell iDRAC Redfish: read-only; discover supported resources dynamically and verify actual server/firmware capabilities.
- NVIDIA DCGM Exporter: metrics flow through Prometheus; backend reads approved Prometheus queries. Verify GPU models, driver/DCGM versions and topology.
- Nutanix Prism Central: version-specific adapter; never guess API paths or versions.
- OpenShift/Kubernetes: approved APIs and least-privilege service accounts.

The frontend never connects directly to hardware or platform endpoints. Backend connector services own integration, normalisation, timeouts, retries, access control and sanitised errors.

## 8. Security requirements
- Use least-privilege identities and read-only access wherever possible.
- Never commit credentials, tokens, private keys, certificates, internal hostnames/IPs, customer data or production evidence.
- Never disable TLS certificate verification.
- Use environment-based configuration and an approved secrets manager.
- Apply bounded timeouts, safe retry policies, input validation and sanitised errors.
- Audit sensitive actions, evidence access, approvals and configuration changes.
- Separate development, test and production environments.
- Use synthetic data in the personal/reference implementation.
- Do not transfer company materials to personal devices or external AI services without explicit organisational approval.

## 9. Delivery sequence
0. Repository and architecture discovery
1. Application foundation and shell
2. Control framework and dimension pages
3. Evidence, assessment, exceptions and approvals
4. Connector framework and mock integrations
5. Dashboard and reporting
6. Live integration and security hardening

## 10. Open decisions
Confirm with the project/platform owners:
- Authoritative control framework and catalogue
- Approved technology versions and repository conventions
- Identity provider and role model
- Hosting/runtime and deployment approach
- Object storage and retention requirements
- Approved connector endpoints, API versions, network paths and service identities
- Audit, data classification and evidence retention requirements
- Whether EY branding/assets may be used in the target environment
