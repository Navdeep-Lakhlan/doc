# GitHub Copilot Instructions — Sovereignty Control Tower

Read `docs/PROJECT_CONTEXT.md` before significant changes. Read the relevant phase prompt in `docs/prompts/`.

- Inspect the existing repository and follow its conventions before changing code.
- Work incrementally; do not implement multiple phases in one task.
- For broad changes, first provide a plan, files likely to change, dependencies, risks and acceptance criteria. Wait for approval.
- Do not invent control IDs/counts/weights, regulatory mappings, live endpoint paths, API versions, hardware capabilities or compliance claims.
- Start with synthetic data and mock connectors. Real integrations require approved platform-team specifications.
- Keep evidence collection state distinct from control assessment state.
- The frontend must not call infrastructure endpoints directly; use backend connector services.
- Never add secrets, tokens, certificates, internal hostnames/IPs, customer data or production evidence to source control.
- Never disable TLS verification. Apply least privilege, timeouts, safe retries and sanitised errors.
- Add or update tests and documentation for behaviour and decisions.
- Explain new dependencies before adding them.
- Product name: **Sovereignty Control Tower**.
- UI palette: charcoal, white, neutral grey and EY gold/yellow; green/amber/red only for status.
- Eight independent dimension pages: Governance, Data, Intelligence, Compute, Operations, Network, Supply Chain and Continuity.
- At task completion, summarise changed files, tests run, results, assumptions and remaining work.
